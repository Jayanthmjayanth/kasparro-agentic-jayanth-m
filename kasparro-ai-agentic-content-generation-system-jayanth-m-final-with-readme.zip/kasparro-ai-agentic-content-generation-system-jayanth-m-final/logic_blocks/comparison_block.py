def compare_products(p): return {'product_a':p['name'],'product_b':{'name':'RadiantGlow Serum','ingredients':['Niacinamide'],'benefits':['Oil control'],'price':'₹799'}}
