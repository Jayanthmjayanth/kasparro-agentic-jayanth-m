def generate_benefits(p): return p['benefits']
