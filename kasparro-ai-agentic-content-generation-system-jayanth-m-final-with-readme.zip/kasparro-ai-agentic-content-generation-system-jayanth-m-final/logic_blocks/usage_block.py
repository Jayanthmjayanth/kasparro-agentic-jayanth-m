def extract_usage(p): return p['usage']
