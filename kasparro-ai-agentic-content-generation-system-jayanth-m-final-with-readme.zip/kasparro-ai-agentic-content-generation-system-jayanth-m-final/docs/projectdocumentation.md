
Problem Statement:
Design a modular agentic content generation system.

Solution Overview:
Message-based multi-agent architecture.

System Design:
Agents communicate through messages with an orchestrator coordinating flow.
