
from core.message import Message
from agents.parser_agent import ParserAgent
from agents.question_agent import QuestionAgent
from agents.content_agent import ContentAgent
from agents.page_agent import PageAgent

data={'Product Name':'GlowBoost Vitamin C Serum','Concentration':'10% Vitamin C','Skin Type':['Oily','Combination'],'Key Ingredients':['Vitamin C','Hyaluronic Acid'],'Benefits':['Brightening','Fades dark spots'],'How to Use':'Apply 2–3 drops in the morning before sunscreen','Side Effects':'Mild tingling for sensitive skin','Price':'₹699'}

agents={'ParserAgent':ParserAgent('ParserAgent'),'QuestionAgent':QuestionAgent('QuestionAgent'),'ContentAgent':ContentAgent('ContentAgent'),'PageAgent':PageAgent('PageAgent')}
agents['ParserAgent'].receive(Message('System','ParserAgent',data))

active=True
while active:
    active=False
    for a in agents.values():
        if a.has_messages():
            r=a.process();active=True
            if r: agents[r.receiver].receive(r)
