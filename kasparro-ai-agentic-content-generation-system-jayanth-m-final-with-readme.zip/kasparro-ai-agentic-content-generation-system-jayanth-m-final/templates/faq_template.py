def faq_template(items): return {'faqs':items}
