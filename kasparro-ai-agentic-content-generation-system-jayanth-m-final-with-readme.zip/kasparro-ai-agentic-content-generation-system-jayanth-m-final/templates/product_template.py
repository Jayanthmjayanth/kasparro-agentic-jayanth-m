def product_template(p): return p
