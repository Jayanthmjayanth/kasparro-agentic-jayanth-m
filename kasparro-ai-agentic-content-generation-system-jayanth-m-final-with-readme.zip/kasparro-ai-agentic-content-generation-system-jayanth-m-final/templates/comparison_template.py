def comparison_template(c): return c
