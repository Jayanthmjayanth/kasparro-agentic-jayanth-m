
from core.agent_base import Agent
from core.message import Message
class QuestionAgent(Agent):
    def process(self):
        p=self.inbox.pop(0).payload
        q={'informational':['What is '+p['name']+'?','What does it do?','Who should use it?'],
           'usage':['How to apply?','When to use?','How much to use?'],
           'safety':['Any side effects?','Safe for sensitive skin?','Can it be used daily?'],
           'purchase':['What is the price?','Is it affordable?','What does price include?'],
           'comparison':['How is it different?','How does it compare?','Why choose this?']}
        return Message(self.name,'ContentAgent',{'product':p,'questions':q})
