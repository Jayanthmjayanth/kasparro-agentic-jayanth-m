
from core.agent_base import Agent
from core.message import Message
class ParserAgent(Agent):
    def process(self):
        m=self.inbox.pop(0);p=m.payload
        model={'name':p['Product Name'],'concentration':p['Concentration'],'skin_type':p['Skin Type'],'ingredients':p['Key Ingredients'],'benefits':p['Benefits'],'usage':p['How to Use'],'side_effects':p['Side Effects'],'price':p['Price']}
        return Message(self.name,'QuestionAgent',model)
