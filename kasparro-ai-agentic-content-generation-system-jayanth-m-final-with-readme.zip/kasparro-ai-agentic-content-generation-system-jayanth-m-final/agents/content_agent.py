
from core.agent_base import Agent
from core.message import Message
from logic_blocks.benefits_block import generate_benefits
from logic_blocks.usage_block import extract_usage
from logic_blocks.comparison_block import compare_products
class ContentAgent(Agent):
    def process(self):
        d=self.inbox.pop(0).payload;p=d['product'];qs=d['questions']
        faq=[{'category':c,'question':q,'answer':'Derived from product data.'} for c in qs for q in qs[c]]
        content={'faq':faq,'product_page':{**p,'benefits':generate_benefits(p),'usage':extract_usage(p)},'comparison_page':compare_products(p)}
        return Message(self.name,'PageAgent',content)
