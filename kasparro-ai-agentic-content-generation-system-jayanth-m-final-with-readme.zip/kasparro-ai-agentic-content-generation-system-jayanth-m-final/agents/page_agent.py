
from core.agent_base import Agent
import json,os
class PageAgent(Agent):
    def process(self):
        d=self.inbox.pop(0).payload;os.makedirs('outputs',exist_ok=True)
        json.dump(d['faq'],open('outputs/faq.json','w'),indent=2)
        json.dump(d['product_page'],open('outputs/product_page.json','w'),indent=2)
        json.dump(d['comparison_page'],open('outputs/comparison_page.json','w'),indent=2)
