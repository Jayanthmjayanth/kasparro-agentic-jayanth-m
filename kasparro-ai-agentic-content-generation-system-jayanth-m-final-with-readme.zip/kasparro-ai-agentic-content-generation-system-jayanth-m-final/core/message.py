class Message:
    def __init__(self,sender,receiver,payload):
        self.sender=sender
        self.receiver=receiver
        self.payload=payload
