class Agent:
    def __init__(self,name):
        self.name=name
        self.inbox=[]
    def receive(self,msg):
        self.inbox.append(msg)
    def has_messages(self):
        return len(self.inbox)>0
    def process(self):
        raise NotImplementedError
